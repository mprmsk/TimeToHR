﻿using System;

namespace TimeConverter.Service
{
    /// <summary>
    /// Class to convert from time to word
    /// </summary>
    public class TimeConverterBO : ITimeConverter
    {
        /// <summary>
        /// Used this array for words 
        /// </summary>
        public string[] words = { "Zero", "One", "Two", "Three", "four",
                            "Five", "Six", "Seven", "Eight", "Nine",
                            "Ten", "Eleven", "Twelve", "Thirteen",
                            "Fourteen", "Fifteen", "Sixteen", "Seventeen",
                            "Eighteen", "Nineteen", "Twenty", "Twenty One",
                            "Twenty Two", "Twenty Three", "Twenty Four",
                            "Twenty Five", "Twenty Six", "Twenty Seven",
                            "Twenty Eight", "Twenty nNine",
                        };
        /// <summary>
        /// Method to convert Time to Word Format.
        /// </summary>
        /// <param name="h"></param>
        /// <param name="m"></param>
        /// <returns></returns>
        public string GetTimeInHumanFormat(int _hours, int _minutes)
        {
            try
            {
                string convertedWord = string.Empty;
                

                if (_minutes == 0)
                    convertedWord = (words[_hours] + " o' clock ");

                else if (_minutes == 1)
                    convertedWord = ("One Past " + words[_hours]);

                else if (_minutes == 59)
                    convertedWord = ("One To " + words[(_hours % 12) + 1]);

                else if (_minutes == 15)
                    convertedWord = ("Quarter Past " + words[_hours]);

                else if (_minutes == 30)
                    convertedWord = ("Half Past " + words[_hours]);

                else if (_minutes == 45)
                    convertedWord = ("Quarter To " + words[(_hours % 12) + 1]);

                else if (_minutes <= 30)
                    convertedWord = (words[_minutes] + " Past " + words[_hours]);

                else if (_minutes > 30)
                    convertedWord = (words[60 - _minutes] + " To " + words[(_hours % 12) + 1]);

                return convertedWord;
            }
            catch (Exception)
            {
                throw;
            }


        }

        // Methods to test will go here     
    }
}
